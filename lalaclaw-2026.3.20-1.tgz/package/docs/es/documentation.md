[English](../en/documentation.md) | [中文](../zh/documentation.md) | [繁體中文（香港）](../zh-hk/documentation.md) | [日本語](../ja/documentation.md) | [한국어](../ko/documentation.md) | [Français](../fr/documentation.md) | [Español](../es/documentation.md) | [Português](../pt/documentation.md) | [Deutsch](../de/documentation.md) | [Bahasa Melayu](../ms/documentation.md) | [தமிழ்](../ta/documentation.md)

# Documentacion de LalaClaw

Esta documentacion se basa en la interfaz, el backend, las pruebas y la configuracion actuales del repositorio. Su objetivo es convertir el comportamiento real de LalaClaw en un arbol de documentos Markdown navegable.

Autor: Marila Wang

## Arbol de documentos

- [Inicio rapido](./documentation-quick-start.md)
- [Resumen de la interfaz](./documentation-interface.md)
- [Conversacion, adjuntos y comandos](./documentation-chat.md)
- [Inspector, vista previa de archivos y rastreo](./documentation-inspector.md)
- [Sesiones, agentes y modos de ejecucion](./documentation-sessions.md)
- [Atajos de teclado](./documentation-shortcuts.md)
- [Persistencia local y recuperacion](./documentation-persistence.md)
- [API y solucion de problemas](./documentation-api-troubleshooting.md)
- [Detalle visual](./documentation-easter-egg.md)

## Lectura recomendada

1. Empieza con [Inicio rapido](./documentation-quick-start.md).
2. Luego lee [Resumen de la interfaz](./documentation-interface.md) y [Conversacion, adjuntos y comandos](./documentation-chat.md).
3. Para el detalle visual de marca, mira [Detalle visual](./documentation-easter-egg.md).
4. Para el panel derecho, lee [Inspector, vista previa de archivos y rastreo](./documentation-inspector.md).
5. Para agentes, modelos y `mock` vs `openclaw`, lee [Sesiones, agentes y modos de ejecucion](./documentation-sessions.md).
6. Para atajos, recuperacion tras recarga y depuracion, lee [Atajos de teclado](./documentation-shortcuts.md), [Persistencia local y recuperacion](./documentation-persistence.md) y [API y solucion de problemas](./documentation-api-troubleshooting.md).
