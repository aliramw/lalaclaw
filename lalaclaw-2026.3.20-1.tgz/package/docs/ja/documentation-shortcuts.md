[English](../en/documentation-shortcuts.md) | [中文](../zh/documentation-shortcuts.md) | [繁體中文（香港）](../zh-hk/documentation-shortcuts.md) | [日本語](../ja/documentation-shortcuts.md) | [한국어](../ko/documentation-shortcuts.md) | [Français](../fr/documentation-shortcuts.md) | [Español](../es/documentation-shortcuts.md) | [Português](../pt/documentation-shortcuts.md) | [Deutsch](../de/documentation-shortcuts.md) | [Bahasa Melayu](../ms/documentation-shortcuts.md) | [தமிழ்](../ta/documentation-shortcuts.md)

[ホームへ戻る](./documentation.md) | [画面概要](./documentation-interface.md) | [チャット、添付、コマンド](./documentation-chat.md) | [ローカル保存と復元](./documentation-persistence.md)

# キーボードショートカット

## 全体

- `Cmd/Ctrl + /`: ショートカットヘルプを開く
- `Cmd/Ctrl + N`: 新しいセッションを開始
- `Cmd/Ctrl + 1-9`: 番号でタブ切替
- `Cmd/Ctrl + Left`: 前のタブへ
- `Cmd/Ctrl + Right`: 次のタブへ

## 外観

- `Shift + Cmd/Ctrl + F`: システム外観に切替
- `Shift + Cmd/Ctrl + L`: ライト外観に切替
- `Shift + Cmd/Ctrl + D`: ダーク外観に切替

## 入力欄

入力欄のショートカットは現在の送信モードで変わります。

- `Enter で送信`
  - `Enter`: 送信
  - `Shift + Enter`: 改行
- `Enter を 2 回で送信`
  - `Enter` 2 連打: 送信
  - `Shift + Enter`: 送信
  - `Enter`: 改行
- `ArrowUp`: 1 つ前の prompt history
- `ArrowDown`: 次の prompt history

## ダイアログとメニュー

- `Esc`: ショートカットダイアログ、メンションメニュー、一部コンテキストメニューを閉じる

## グローバル入力捕捉

明示的なショートカットとは別に、入力を楽にする小さな挙動があります。

- Composer にフォーカスがない状態で通常文字やスペースを打つと、自動で composer にフォーカスが移り、その文字が入力される

## 関連ページ

- 保存状態、添付復元、リロード復元は [ローカル保存と復元](./documentation-persistence.md)
- メッセージ送信、prompt history、Slash コマンドは [チャット、添付、コマンド](./documentation-chat.md)
