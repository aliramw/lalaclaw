[English](../en/documentation.md) | [中文](../zh/documentation.md) | [繁體中文（香港）](../zh-hk/documentation.md) | [日本語](../ja/documentation.md) | [한국어](../ko/documentation.md) | [Français](../fr/documentation.md) | [Español](../es/documentation.md) | [Português](../pt/documentation.md) | [Deutsch](../de/documentation.md) | [Bahasa Melayu](../ms/documentation.md) | [தமிழ்](../ta/documentation.md)

# Dokumentasi LalaClaw

Dokumentasi ini berdasarkan bahagian hadapan, bahagian belakang, ujian dan konfigurasi semasa dalam repositori ini. Tujuannya ialah menjadikan tingkah laku sebenar LalaClaw lebih mudah diterokai melalui halaman Markdown.

Pengarang: Marila Wang

## Pokok Dokumen

- [Mula cepat](./documentation-quick-start.md)
- [Gambaran antara muka](./documentation-interface.md)
- [Sembang, lampiran dan arahan](./documentation-chat.md)
- [Pemeriksa, pratonton fail dan penjejakan](./documentation-inspector.md)
- [Sesi, ejen dan mod pelaksanaan](./documentation-sessions.md)
- [Pintasan papan kekunci](./documentation-shortcuts.md)
- [Persistensi tempatan dan pemulihan](./documentation-persistence.md)
- [API dan penyelesaian masalah](./documentation-api-troubleshooting.md)
- [Telur paskah](./documentation-easter-egg.md)

## Cadangan Bacaan

1. Mulakan dengan [Mula cepat](./documentation-quick-start.md).
2. Kemudian baca [Gambaran antara muka](./documentation-interface.md) dan [Sembang, lampiran dan arahan](./documentation-chat.md).
3. Untuk panel kanan, baca [Pemeriksa, pratonton fail dan penjejakan](./documentation-inspector.md).
4. Untuk ejen, model dan perbezaan antara `mock` dan `openclaw`, baca [Sesi, ejen dan mod pelaksanaan](./documentation-sessions.md).
5. Untuk operasi dan penyahpepijatan, baca [Pintasan papan kekunci](./documentation-shortcuts.md), [Persistensi tempatan dan pemulihan](./documentation-persistence.md) dan [API dan penyelesaian masalah](./documentation-api-troubleshooting.md).
