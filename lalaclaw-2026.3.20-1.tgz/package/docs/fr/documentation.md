[English](../en/documentation.md) | [中文](../zh/documentation.md) | [繁體中文（香港）](../zh-hk/documentation.md) | [日本語](../ja/documentation.md) | [한국어](../ko/documentation.md) | [Français](../fr/documentation.md) | [Español](../es/documentation.md) | [Português](../pt/documentation.md) | [Deutsch](../de/documentation.md) | [Bahasa Melayu](../ms/documentation.md) | [தமிழ்](../ta/documentation.md)

# Documentation LalaClaw

Cette documentation est produite à partir de la partie interface, du backend, des tests et de la configuration actuels du dépôt. Son but est de transformer le comportement réel de LalaClaw en un arbre de documents Markdown facile à parcourir.

Auteur : Marila Wang

## Arbre documentaire

- [Démarrage rapide](./documentation-quick-start.md)
- [Vue d'ensemble de l'interface](./documentation-interface.md)
- [Discussion, pièces jointes et commandes](./documentation-chat.md)
- [Inspecteur, aperçu de fichiers et traçage](./documentation-inspector.md)
- [Sessions, agents et modes d'exécution](./documentation-sessions.md)
- [Raccourcis clavier](./documentation-shortcuts.md)
- [Persistance locale et reprise](./documentation-persistence.md)
- [API et dépannage](./documentation-api-troubleshooting.md)
- [Clin d'oeil visuel](./documentation-easter-egg.md)

## Ordre de lecture conseillé

1. Commencez par [Démarrage rapide](./documentation-quick-start.md) pour lancer l'interface et le backend.
2. Lisez ensuite [Vue d'ensemble de l'interface](./documentation-interface.md) et [Discussion, pièces jointes et commandes](./documentation-chat.md) pour comprendre le flux principal.
3. Pour le petit détail de marque, consultez [Clin d'oeil visuel](./documentation-easter-egg.md).
4. Pour le panneau de trace à droite, lisez [Inspecteur, aperçu de fichiers et traçage](./documentation-inspector.md).
5. Pour les agents, les modèles et `mock` vs `openclaw`, lisez [Sessions, agents et modes d'exécution](./documentation-sessions.md).
6. Pour les raccourcis, la reprise après rechargement et le débogage API, lisez [Raccourcis clavier](./documentation-shortcuts.md), [Persistance locale et reprise](./documentation-persistence.md) et [API et dépannage](./documentation-api-troubleshooting.md).

## Ce que vous pouvez faire

- Discuter avec l'agent courant dans le navigateur et envoyer des images, fichiers texte ou pièces jointes classiques.
- Ouvrir des onglets de session séparés pour différents agents, chacun avec son propre modèle, mode rapide et mode de réflexion.
- Consulter les journaux d'exécution, l'activité fichiers, les résumés, l'environnement, la collaboration et les aperçus dans l'inspecteur.
- Utiliser l'interface complète en mode `mock` ou la connecter à une passerelle OpenClaw locale pour des exécutions réelles.

## Lectures associées

- [Vue d'ensemble de l'architecture](./architecture.md)
- [Présentation produit](./showcase.md)
- [Feuille de route de refactorisation](./refactor-roadmap.md)
