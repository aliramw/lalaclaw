[English](../en/refactor-roadmap.md) | [中文](../zh/refactor-roadmap.md) | [繁體中文（香港）](../zh-hk/refactor-roadmap.md) | [日本語](../ja/refactor-roadmap.md) | [한국어](../ko/refactor-roadmap.md) | [Français](../fr/refactor-roadmap.md) | [Español](../es/refactor-roadmap.md) | [Português](../pt/refactor-roadmap.md) | [Deutsch](../de/refactor-roadmap.md) | [Bahasa Melayu](../ms/refactor-roadmap.md) | [தமிழ்](../ta/refactor-roadmap.md)

# Feuille de route de refactorisation

> Navigation : [Accueil de la documentation](./documentation.md) | [Sessions, agents et modes d'exécution](./documentation-sessions.md) | [API et dépannage](./documentation-api-troubleshooting.md) | [Vue d'ensemble de l'architecture](./architecture.md) | [Présentation produit](./showcase.md)

## Objectifs

- Réduire le risque de maintenance de `src/App.jsx` et `server.js`
- Séparer la composition d'interface, l'orchestration de données et l'intégration OpenClaw
- Garder le comportement actuel stable tout en rendant les tests plus ciblés

## Forme cible

### Interface applicative

- `src/app/bootstrap/`
- `src/features/session/`
- `src/features/chat/`
- `src/features/inspector/`
- `src/shared/`

### Serveur backend

- `server/config.js`
- `server/session-store.js`
- `server/openclaw-client.js`
- `server/transcript.js`
- `server/routes.js`
- `server/index.js`

## Premiers PR suggérés

1. Extraire la configuration runtime côté serveur
2. Extraire le flux d'envoi de la discussion côté interface
3. Extraire le polling runtime côté interface
4. Ajouter des fixtures de transcript
5. Supprimer définitivement l'ancienne app statique
