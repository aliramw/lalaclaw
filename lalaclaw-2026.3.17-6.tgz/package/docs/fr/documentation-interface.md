[English](../en/documentation-interface.md) | [中文](../zh/documentation-interface.md) | [繁體中文（香港）](../zh-hk/documentation-interface.md) | [日本語](../ja/documentation-interface.md) | [한국어](../ko/documentation-interface.md) | [Français](../fr/documentation-interface.md) | [Español](../es/documentation-interface.md) | [Português](../pt/documentation-interface.md) | [Deutsch](../de/documentation-interface.md) | [Bahasa Melayu](../ms/documentation-interface.md) | [தமிழ்](../ta/documentation-interface.md)

[Retour à l'accueil](./documentation.md) | [Démarrage rapide](./documentation-quick-start.md) | [Clin d'oeil visuel](./documentation-easter-egg.md) | [Discussion, pièces jointes et commandes](./documentation-chat.md) | [Inspecteur, aperçu de fichiers et traçage](./documentation-inspector.md)

# Vue d'ensemble de l'interface

L'écran principal de LalaClaw se compose de trois parties : un en-tête de contrôle de session, un espace de chat et un inspecteur à droite.

## En-tête et contrôles de session

La zone supérieure inclut :

- La sélection du modèle courant
- L'affichage de l'usage du contexte
- Le basculement du mode rapide
- Le choix du mode de réflexion parmi `off / minimal / low / medium / high / xhigh / adaptive`
- Le changement de langue
- Le changement de thème `system / light / dark`
- L'aide des raccourcis clavier
- Le homard cliquable en haut à gauche, documenté dans [Clin d'oeil visuel](./documentation-easter-egg.md)

## Espace de chat

Le panneau principal contient :

- Une barre d'onglets de session
- Un en-tête avec l'agent courant, l'état d'activité, la taille de police et l'action de nouvelle session
- Une zone de conversation pour les messages, les réponses en flux et les aperçus de pièces jointes
- Un composer prenant en charge le texte, les mentions `@`, les pièces jointes et l'arrêt d'une réponse en cours

## Inspecteur à droite

L'inspecteur expose six surfaces principales :

- `Journal d'exécution`
- `Fichiers`
- `Résumés`
- `Environnement`
- `Collaboration`
- `Aperçu`

Il est synchronisé avec la session de chat : activité fichiers, appels d'outils, résumés et snapshots d'environnement y apparaissent.

## Où aller ensuite

- Pour l'envoi, les pièces jointes, les files d'attente et les commandes : [Discussion, pièces jointes et commandes](./documentation-chat.md)
- Pour le détail de l'inspecteur : [Inspecteur, aperçu de fichiers et traçage](./documentation-inspector.md)
