[English](../en/documentation-inspector.md) | [中文](../zh/documentation-inspector.md) | [繁體中文（香港）](../zh-hk/documentation-inspector.md) | [日本語](../ja/documentation-inspector.md) | [한국어](../ko/documentation-inspector.md) | [Français](../fr/documentation-inspector.md) | [Español](../es/documentation-inspector.md) | [Português](../pt/documentation-inspector.md) | [Deutsch](../de/documentation-inspector.md) | [Bahasa Melayu](../ms/documentation-inspector.md) | [தமிழ்](../ta/documentation-inspector.md)

[Voltar ao inicio](./documentation.md) | [Visao geral da interface](./documentation-interface.md) | [Conversa, anexos e comandos](./documentation-chat.md) | [API e solucao de problemas](./documentation-api-troubleshooting.md)

# Inspetor, pre-visualizacao de arquivos e rastreamento

O inspetor da direita centraliza trilha de execucao, atividade de arquivos, resumos e dados de ambiente da sessao atual.

- `Registro de execucao`
- `Arquivos`
- `Resumos`
- `Ambiente`
- `Colaboracao`
- `Pre-visualizacao`
